package com.loay.bastati

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Database(context: Context) : SQLiteOpenHelper(context, "bastati.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT NOT NULL)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '', note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '', note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, buy REAL NOT NULL DEFAULT 0, sell REAL NOT NULL DEFAULT 0, qty REAL NOT NULL DEFAULT 0, unit TEXT DEFAULT 'قطعة')")
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, customer_name TEXT NOT NULL, date TEXT NOT NULL, total REAL NOT NULL, paid REAL NOT NULL DEFAULT 0, type TEXT NOT NULL DEFAULT 'SALE', note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, product_name TEXT NOT NULL, qty REAL NOT NULL, price REAL NOT NULL, line_total REAL NOT NULL)")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, customer_name TEXT NOT NULL, date TEXT NOT NULL, amount REAL NOT NULL, note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, date TEXT NOT NULL, amount REAL NOT NULL, note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE suppliers_bills(id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id INTEGER, supplier_name TEXT NOT NULL, date TEXT NOT NULL, total REAL NOT NULL, paid REAL NOT NULL DEFAULT 0, note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE supplier_items(id INTEGER PRIMARY KEY AUTOINCREMENT, bill_id INTEGER NOT NULL, product_name TEXT NOT NULL, qty REAL NOT NULL, price REAL NOT NULL, line_total REAL NOT NULL)")
        db.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, action TEXT NOT NULL, details TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun setting(key: String, fallback: String = ""): String {
        readableDatabase.rawQuery("SELECT v FROM settings WHERE k=?", arrayOf(key)).use { if (it.moveToFirst()) return it.getString(0) }
        return fallback
    }
    fun setSetting(key: String, value: String) { val v=ContentValues().apply { put("k",key); put("v",value) }; writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE) }
    fun add(table: String, values: ContentValues): Long = writableDatabase.insert(table, null, values)
    fun update(table: String, id: Long, values: ContentValues) { writableDatabase.update(table, values, "id=?", arrayOf(id.toString())) }
    fun delete(table: String, id: Long) { writableDatabase.delete(table, "id=?", arrayOf(id.toString())) }
    fun rows(sql: String, args: Array<String> = emptyArray(), block: (android.database.Cursor) -> Unit) { readableDatabase.rawQuery(sql,args).use { while(it.moveToNext()) block(it) } }
    fun scalar(sql: String): Double { readableDatabase.rawQuery(sql,null).use { return if(it.moveToFirst()) it.getDouble(0) else 0.0 } }
    fun audit(action: String, details: String) { val v=ContentValues().apply { put("date", now()); put("action",action); put("details",details) }; add("audit",v) }
}

fun now(): String = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
fun money(v: Double): String = String.format(java.util.Locale.US, "%.2f ₪", v)
