package com.loay.hisabati
import android.content.*
import android.database.sqlite.*
data class Person(val id:Long,val name:String,val phone:String,val balance:Double)
data class Move(val date:String,val person:String,val type:String,val description:String,val amount:Double)
class Database(c:Context):SQLiteOpenHelper(c,"hisabati.db",null,1) {
 override fun onCreate(d:SQLiteDatabase) {
  d.execSQL("CREATE TABLE people(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT)")
  d.execSQL("CREATE TABLE moves(id INTEGER PRIMARY KEY AUTOINCREMENT,person_id INTEGER,type TEXT,description TEXT,qty REAL,price REAL,amount REAL,date TEXT)")
 }
 override fun onUpgrade(d:SQLiteDatabase,o:Int,n:Int) {}
 fun addPerson(n:String,p:String) { writableDatabase.insertOrThrow("people",null,ContentValues().apply{put("name",n);put("phone",p)}) }
 fun people():List<Person> {
  val a=mutableListOf<Person>()
  readableDatabase.rawQuery("SELECT p.id,p.name,p.phone,COALESCE(SUM(CASE WHEN m.type='DEBT' THEN m.amount WHEN m.type='PAYMENT' THEN -m.amount ELSE 0 END),0) FROM people p LEFT JOIN moves m ON m.person_id=p.id GROUP BY p.id ORDER BY p.name",null).use {
   while(it.moveToNext()) a.add(Person(it.getLong(0),it.getString(1),it.getString(2)?: "",it.getDouble(3)))
  }; return a
 }
 fun addMove(pid:Long?,type:String,desc:String,q:Double,price:Double) {
  require(q>0 && price>0); val amount=q*price
  writableDatabase.insertOrThrow("moves",null,ContentValues().apply {
   if(pid==null) putNull("person_id") else put("person_id",pid)
   put("type",type);put("description",desc);put("qty",q);put("price",price);put("amount",amount)
   put("date",java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.US).format(java.util.Date()))
  })
 }
 fun moves():List<Move> {
  val a=mutableListOf<Move>()
  readableDatabase.rawQuery("SELECT m.date,COALESCE(p.name,'—'),m.type,m.description,m.amount FROM moves m LEFT JOIN people p ON p.id=m.person_id ORDER BY m.id DESC",null).use {
   while(it.moveToNext()) a.add(Move(it.getString(0),it.getString(1),it.getString(2),it.getString(3)?: "",it.getDouble(4)))
  };return a
 }
 fun totals():Triple<Double,Double,Double> {
  var inc=0.0;var exp=0.0;var debt=0.0
  readableDatabase.rawQuery("SELECT type,SUM(amount) FROM moves GROUP BY type",null).use {
   while(it.moveToNext()) when(it.getString(0)) {
    "SALE","PAYMENT"->inc+=it.getDouble(1)
    "EXPENSE","PURCHASE"->exp+=it.getDouble(1)
    "DEBT"->debt+=it.getDouble(1)
   }
  };return Triple(inc,exp,debt)
 }
}
