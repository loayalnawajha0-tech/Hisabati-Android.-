package com.loay.hisabati

import android.app.*
import android.os.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfDocument
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.res.ColorStateList
import java.io.File
import java.io.FileOutputStream
import java.text.DecimalFormat

class MainActivity : Activity() {
    private lateinit var db: Database
    private lateinit var body: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences
    private var dark = true
    private val fmt = DecimalFormat("#,##0.00")

    private val bg get() = if (dark) 0xff0d1422.toInt() else 0xfff3f6fb.toInt()
    private val surface get() = if (dark) 0xff172235.toInt() else 0xffffffff.toInt()
    private val surface2 get() = if (dark) 0xff202e43.toInt() else 0xffe8eef7.toInt()
    private val text get() = if (dark) 0xfff2f5fb.toInt() else 0xff17243a.toInt()
    private val muted get() = if (dark) 0xffaab6c8.toInt() else 0xff68778d.toInt()
    private val blue = 0xff5795f5.toInt()
    private val green = 0xff36bd91.toInt()
    private val red = 0xffed7777.toInt()
    private val amber = 0xffffc66d.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Database(this)
        prefs = getSharedPreferences("hisabati_settings", MODE_PRIVATE)
        dark = prefs.getBoolean("dark_mode", true)
        home()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun label(s: String, size: Float = 15f, color: Int = text, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }

    private fun button(s: String, color: Int = blue, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = s; textSize = 14f; setTextColor(0xffffffff.toInt())
            gravity = Gravity.CENTER; setPadding(dp(12), dp(13), dp(12), dp(13))
            background = shape(color, 14); setOnClickListener { onClick() }
        }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText; textSize = 15f; setSingleLine(true); gravity = Gravity.RIGHT
        setTextColor(this@MainActivity.text); setHintTextColor(this@MainActivity.muted)
        background = shape(surface2, 12)
        setPadding(dp(14), dp(10), dp(14), dp(10))
    }

    private fun screen(title: String, subtitle: String = "إدارة أموالك بكل سهولة") {
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = if (dark) 0 else
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(label(title, 23f, text, true))
        titleBox.addView(label(subtitle, 12f, muted))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        val theme = TextView(this).apply {
            text = if (dark) "☀" else "☾"; textSize = 23f; gravity = Gravity.CENTER
            setTextColor(amber); background = shape(surface2, 15)
            setPadding(dp(13), dp(8), dp(13), dp(8))
            setOnClickListener {
                dark = !dark; prefs.edit().putBoolean("dark_mode", dark).apply()
                home()
            }
        }
        header.addView(theme)
        root.addView(header)

        val scroll = ScrollView(this).apply { clipToPadding = false }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, dp(16))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(surface, 18)
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        listOf(
            Triple("⌂", "الرئيسية") { home() },
            Triple("♙", "الزبائن") { customers() },
            Triple("＋", "حركة") { newMove() },
            Triple("▤", "التقارير") { reports() }
        ).forEachIndexed { index, item ->
            val v = TextView(this).apply {
                text = "${item.first}\n${item.second}"; textSize = 11f
                gravity = Gravity.CENTER; setTextColor(if ((title.contains("الرئيسية") && index == 0) ||
                    (title.contains("الزبائن") && index == 1) ||
                    (title.contains("حركة") && index == 2) ||
                    (title.contains("التقارير") && index == 3)) blue else muted)
                setPadding(0, dp(7), 0, dp(7))
                setOnClickListener { item.third() }
            }
            nav.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun section(title: String) {
        body.addView(label(title, 17f, text, true).apply {
            setPadding(dp(2), dp(12), dp(2), dp(8))
        })
    }

    private fun panel(content: View, color: Int = surface) {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(color, 18)
            setPadding(dp(15), dp(12), dp(15), dp(12))
        }
        wrapper.addView(content)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        body.addView(wrapper, lp)
    }

    private fun metric(icon: String, title: String, value: String, accent: Int) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val iconView = TextView(this).apply {
            text = icon; textSize = 22f; gravity = Gravity.CENTER
            setTextColor(accent); background = shape(surface2, 14)
            setPadding(dp(12), dp(9), dp(12), dp(9))
        }
        row.addView(iconView)
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        texts.addView(label(title, 12f, muted))
        texts.addView(label(value, 20f, text, true))
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginEnd = dp(12)
        })
        panel(row)
    }

    private fun home() {
        screen("حساباتي", "ملخص حساباتك اليوم")
        val (income, expenses, debts) = db.totals()
        val balance = db.people().sumOf { it.balance }
        val welcome = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        welcome.addView(label("أهلاً بك 👋", 19f, text, true))
        welcome.addView(label("كل حساباتك في مكان واحد، وبخطوات بسيطة.", 12f, muted))
        panel(welcome, surface2)
        metric("↗", "إجمالي المقبوضات", "${fmt.format(income)} ₪", green)
        metric("↘", "المصروفات والمشتريات", "${fmt.format(expenses)} ₪", red)
        metric("◷", "الديون المسجلة", "${fmt.format(debts)} ₪", amber)
        metric("♙", "المتبقي على الزبائن", "${fmt.format(balance)} ₪", if (balance > 0) red else green)

        section("اختصارات سريعة")
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("＋  حركة جديدة", blue) { newMove() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        actions.addView(button("♙  إضافة زبون", green) { addCustomer() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        body.addView(actions)
        section("آخر الحركات")
        val moves = db.moves().take(6)
        if (moves.isEmpty()) emptyState("لا توجد حركات حتى الآن", "ابدأ بإضافة زبون أو تسجيل أول حركة مالية.")
        moves.forEach { m ->
            val color = when (m.type) { "PAYMENT", "SALE" -> green; "EXPENSE", "PURCHASE" -> red; else -> amber }
            val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            v.addView(label("${typeName(m.type)} • ${m.person}", 14f, text, true))
            v.addView(label("${m.description}   |   ${m.date}", 11f, muted))
            v.addView(label("${fmt.format(m.amount)} ₪", 15f, color, true))
            panel(v)
        }
    }

    private fun emptyState(title: String, hint: String) {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        v.addView(label("✦", 28f, blue, true).apply { gravity = Gravity.CENTER })
        v.addView(label(title, 15f, text, true).apply { gravity = Gravity.CENTER })
        v.addView(label(hint, 12f, muted).apply { gravity = Gravity.CENTER })
        panel(v, surface2)
    }

    private fun customers() {
        screen("الزبائن", "قائمة العملاء وأرصدتهم")
        body.addView(button("＋   إضافة زبون جديد", green) { addCustomer() })
        section("جميع الزبائن")
        val people = db.people()
        if (people.isEmpty()) emptyState("لا يوجد زبائن بعد", "أضف أول زبون لبدء تسجيل الديون والدفعات.")
        people.forEach { p ->
            val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            v.addView(label("♙  ${p.name}", 16f, text, true))
            v.addView(label(if (p.phone.isBlank()) "لا يوجد رقم هاتف" else "☎  ${p.phone}", 12f, muted))
            v.addView(label("الرصيد المستحق: ${fmt.format(p.balance)} ₪",
                14f, if (p.balance > 0) red else green, true))
            v.addView(button("＋  تسجيل دين أو دفعة", blue) { newMove(p) })
            panel(v)
        }
    }

    private fun addCustomer() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        val n = field("اسم الزبون"); val p = field("رقم الهاتف")
        box.addView(n); box.addView(p)
        AlertDialog.Builder(this).setTitle("إضافة زبون").setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                if (n.text.isNotBlank()) { db.addPerson(n.text.toString(), p.text.toString()); customers() }
                else toast("اسم الزبون مطلوب")
            }.show()
    }

    private fun newMove(pre: Person? = null) {
        screen("حركة مالية", "سجّل العملية بسهولة")
        val types = listOf("دين على زبون", "دفعة من زبون", "بيع نقدي", "مصروف", "شراء")
        val codes = listOf("DEBT", "PAYMENT", "SALE", "EXPENSE", "PURCHASE")
        section("نوع العملية")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
        sp.background = shape(surface2, 12)
        body.addView(sp)
        section("الزبون")
        val people = db.people()
        val ps = Spinner(this)
        ps.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            if (people.isEmpty()) listOf("لا يوجد زبائن") else people.map { it.name })
        ps.background = shape(surface2, 12)
        body.addView(ps)
        if (pre != null) ps.setSelection(people.indexOfFirst { it.id == pre.id }.coerceAtLeast(0))
        val desc = field("وصف العملية أو المنتج")
        val qty = field("الكمية"); qty.setText("1")
        val price = field("سعر الوحدة بالشيكل")
        listOf("الوصف", "الكمية", "سعر الوحدة").forEach { section(it) }
        body.addView(desc); body.addView(qty); body.addView(price)
        val total = label("الإجمالي: 0.00 ₪", 20f, green, true)
        panel(total, surface2)
        val calc = {
            val q = qty.text.toString().toDoubleOrNull() ?: 0.0
            val p = price.text.toString().toDoubleOrNull() ?: 0.0
            total.text = "الإجمالي: ${fmt.format(q * p)} ₪"
        }
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { calc() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        qty.addTextChangedListener(watcher); price.addTextChangedListener(watcher)
        body.addView(button("✓   حفظ الحركة", green) {
            val ix = sp.selectedItemPosition
            val q = qty.text.toString().toDoubleOrNull() ?: 0.0
            val p = price.text.toString().toDoubleOrNull() ?: 0.0
            if (q <= 0 || p <= 0) toast("أدخل كمية وسعراً صحيحين")
            else if (ix < 2 && people.isEmpty()) toast("أضف زبوناً أولاً")
            else try {
                db.addMove(if (ix < 2) people.getOrNull(ps.selectedItemPosition)?.id else null,
                    codes[ix], desc.text.toString(), q, p)
                toast("تم حفظ الحركة بنجاح"); home()
            } catch (ex: Exception) { toast("تعذر الحفظ: ${ex.message}") }
        })
        body.addView(label("يتم حساب الإجمالي تلقائياً: الكمية × سعر الوحدة", 12f, muted))
    }

    private fun reports() {
        screen("التقارير", "ملخص واضح لحركة أموالك")
        val (income, expenses, debts) = db.totals()
        metric("↗", "المقبوضات", "${fmt.format(income)} ₪", green)
        metric("↘", "المصروفات والمشتريات", "${fmt.format(expenses)} ₪", red)
        metric("◷", "الديون المسجلة", "${fmt.format(debts)} ₪", amber)
        metric("♙", "أرصدة الزبائن", "${fmt.format(db.people().sumOf { it.balance })} ₪", blue)
        body.addView(button("▤   إنشاء تقرير PDF", blue) { pdf() })
        body.addView(label("يمكنك حفظ التقرير ومشاركته من جهازك بعد إنشائه.", 12f, muted))
    }

    private fun typeName(type: String) = when (type) {
        "DEBT" -> "دين"; "PAYMENT" -> "دفعة"; "SALE" -> "بيع نقدي"
        "EXPENSE" -> "مصروف"; "PURCHASE" -> "شراء"; else -> type
    }

    private fun pdf() {
        try {
            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
            val c = page.canvas
            val p = Paint().apply { color = android.graphics.Color.BLACK; textSize = 18f; typeface = Typeface.DEFAULT_BOLD }
            c.drawText("Hisabati - Financial Summary", 38f, 48f, p)
            p.textSize = 12f; p.typeface = Typeface.DEFAULT
            c.drawText("Currency: ILS | ${java.util.Date()}", 38f, 72f, p)
            val (inc, exp, debt) = db.totals(); var y = 112f
            listOf("Receipts: ${fmt.format(inc)} ILS", "Expenses and purchases: ${fmt.format(exp)} ILS",
                "Registered debts: ${fmt.format(debt)} ILS",
                "Outstanding customer balances: ${fmt.format(db.people().sumOf { it.balance })} ILS",
                "CUSTOMER BALANCES").forEach { c.drawText(it, 38f, y, p); y += 24 }
            db.people().forEach { if (y < 810) { c.drawText("${it.name}: ${fmt.format(it.balance)} ILS", 38f, y, p); y += 20 } }
            doc.finishPage(page)
            val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir
            val file = File(dir, "Hisabati_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }; doc.close()
            AlertDialog.Builder(this).setTitle("تم إنشاء التقرير")
                .setMessage("تم حفظ التقرير في:\n${file.absolutePath}")
                .setPositiveButton("حسناً", null).show()
        } catch (e: Exception) { toast("خطأ في إنشاء PDF: ${e.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
