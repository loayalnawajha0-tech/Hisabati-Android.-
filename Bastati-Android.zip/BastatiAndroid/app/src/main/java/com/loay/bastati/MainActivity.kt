package com.loay.bastati

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: Database
    private var dark = true
    private var page = "home"
    private var root: LinearLayout? = null
    private var body: LinearLayout? = null
    private val gold = Color.rgb(201,163,78)
    private val darkBg = Color.rgb(16,17,20)
    private val darkCard = Color.rgb(34,36,41)
    private val lightBg = Color.rgb(246,244,238)
    private val lightCard = Color.WHITE
    private val ink = Color.rgb(35,35,35)
    private val createBackup = 101
    private val restoreBackup = 102
    private val createPdf = 103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Database(this)
        dark = db.setting("dark", "1") == "1"
        if (db.setting("owner").isBlank()) showWelcomeSetup() else showPage("home")
    }

    private fun showWelcomeSetup() {
        val input = EditText(this).apply { hint = "اسم صاحب البسطة"; setTextColor(if(dark) Color.WHITE else ink); setHintTextColor(Color.GRAY) }
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,12,28,4); addView(input) }
        AlertDialog.Builder(this).setTitle("مرحباً بك في بسطتي").setMessage("خلينا نجهز تطبيقك. ما اسم صاحب البسطة؟").setView(box)
            .setCancelable(false).setPositiveButton("ابدأ") { _, _ ->
                val name=input.text.toString().trim().ifBlank { "صاحب البسطة" }
                db.setSetting("owner",name); db.audit("إعداد أولي","تسجيل صاحب البسطة: $name"); showPage("home")
                if(db.setting("welcome_voice","0")=="1") Toast.makeText(this,"أهلاً $name، نورت بسطتي",Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun bg() = if(dark) darkBg else lightBg
    private fun card() = if(dark) darkCard else lightCard
    private fun fg() = if(dark) Color.WHITE else ink
    private fun muted() = if(dark) Color.LTGRAY else Color.DKGRAY

    private fun showPage(which: String) {
        page=which
        val outer=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg()) }
        val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(18,16,18,14) }
        val title=TextView(this).apply { text="بسطتي"; textSize=25f; setTextColor(gold); typeface=Typeface.DEFAULT_BOLD }
        val subtitle=TextView(this).apply { text="إدارة البسطة والحسابات"; textSize=11f; setTextColor(muted()); gravity=Gravity.END }
        header.addView(LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(title); addView(subtitle) }, LinearLayout.LayoutParams(0,-2,1f))
        val theme=Button(this).apply { text=if(dark) "☀" else "☾"; setTextColor(gold); setOnClickListener { dark=!dark; db.setSetting("dark",if(dark) "1" else "0"); showPage(page) } }
        header.addView(theme); outer.addView(header)
        val scroll=ScrollView(this)
        body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,4,16,20) }
        scroll.addView(body); outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(4,6,4,6); setBackgroundColor(card()) }
        listOf("home" to "الرئيسية", "sales" to "فاتورة", "customers" to "الزبائن", "products" to "الأصناف", "more" to "المزيد").forEach { (key,label) ->
            val b=TextView(this).apply { text=label; textSize=12f; gravity=Gravity.CENTER; setTextColor(if(page==key) gold else muted()); setPadding(4,12,4,12); setOnClickListener { showPage(key) } }
            nav.addView(b,LinearLayout.LayoutParams(0,-2,1f))
        }
        outer.addView(nav)
        setContentView(outer)
        when(which){
            "home" -> home()
            "sales" -> invoiceScreen(false)
            "purchases" -> invoiceScreen(true)
            "customers" -> customers()
            "products" -> products()
            "suppliers" -> suppliers()
            "debts" -> debts()
            "reports" -> reports()
            "settings" -> settings()
            else -> more()
        }
    }

    private fun addText(parent: LinearLayout, text: String, size: Float=15f, color: Int=fg(), bold: Boolean=false) {
        parent.addView(TextView(this).apply { this.text=text; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(2,7,2,7) })
    }
    private fun panel(title: String, value: String, detail: String="") {
        val b=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,12,16,12); setBackgroundColor(card()) }
        addText(b,title,13f,muted()); addText(b,value,23f,gold,true); if(detail.isNotBlank()) addText(b,detail,11f,muted())
        body?.addView(b,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 })
    }
    private fun action(label:String, onClick:()->Unit) {
        val b=Button(this).apply { text=label; setTextColor(gold); isAllCaps=false; setOnClickListener { onClick() } }
        body?.addView(b,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=5 })
    }
    private fun home() {
        val owner=db.setting("owner","صاحب البسطة")
        addText(body!!,"أهلاً $owner 👋",20f,fg(),true)
        addText(body!!,"ملخص نشاط البسطة",13f,muted())
        val sales=db.scalar("SELECT COALESCE(SUM(total),0) FROM invoices WHERE type='SALE'")
        val paid=db.scalar("SELECT COALESCE(SUM(paid),0) FROM invoices WHERE type='SALE'")
        val debt=db.scalar("SELECT COALESCE(SUM(total-paid),0) FROM invoices WHERE type='SALE'")
        val purchases=db.scalar("SELECT COALESCE(SUM(total),0) FROM invoices WHERE type='PURCHASE'")
        val expenses=db.scalar("SELECT COALESCE(SUM(amount),0) FROM expenses")
        panel("إجمالي المبيعات",money(sales),"المبالغ المسجلة في فواتير البيع")
        panel("المبالغ المحصلة",money(paid))
        panel("ديون الزبائن المتبقية",money(debt))
        panel("المشتريات المسجلة",money(purchases))
        panel("المصروفات",money(expenses))
        addText(body!!,"اختصارات سريعة",16f,gold,true)
        action("＋ فاتورة بيع جديدة") { showPage("sales") }
        action("＋ تسجيل مشتريات البسطة") { showPage("purchases") }
        action("＋ قبض دفعة من زبون") { paymentDialog() }
        action("＋ إضافة مصروف") { expenseDialog() }
        action("كشف الديون") { showPage("debts") }
    }

    private fun field(hintText:String, number:Boolean=false): EditText = EditText(this).apply {
        hint=hintText; textSize=15f; setTextColor(fg()); setHintTextColor(muted()); setSingleLine(true)
        if(number) inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
    private data class InvoiceRow(val name: EditText, val qty: EditText, val price: EditText, val total: TextView)

    private fun invoiceScreen(purchase:Boolean) {
        addText(body!!,if(purchase)"فاتورة مشتريات جديدة" else "فاتورة بيع جديدة",20f,gold,true)
        val party=field(if(purchase)"اسم المورد" else "اسم الزبون")
        val phone=field("رقم الهاتف (اختياري)")
        body!!.addView(party); body!!.addView(phone)
        addText(body!!,"الأصناف والكميات والأسعار",14f,muted(),true)
        val rowsBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        body!!.addView(rowsBox)
        val rows=mutableListOf<InvoiceRow>()
        val totalView=TextView(this).apply { text="الإجمالي: 0.00 ₪"; textSize=21f; setTextColor(gold); typeface=Typeface.DEFAULT_BOLD; setPadding(0,12,0,12) }
        fun totalValue()=rows.sumOf { (it.qty.text.toString().toDoubleOrNull()?:0.0)*(it.price.text.toString().toDoubleOrNull()?:0.0) }
        fun updateTotal(){ totalView.text="الإجمالي: ${money(totalValue())}" }
        fun addRow() {
            val wrap=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(10,8,10,8); setBackgroundColor(card()) }
            val name=field("اسم الصنف")
            val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            val qty=field("الكمية",true); val price=field("سعر الوحدة",true)
            val total=TextView(this).apply { text="0.00 ₪"; setTextColor(gold); gravity=Gravity.CENTER; textSize=14f }
            line.addView(qty,LinearLayout.LayoutParams(0,-2,1f)); line.addView(price,LinearLayout.LayoutParams(0,-2,1f)); line.addView(total,LinearLayout.LayoutParams(0,-2,1f))
            wrap.addView(name); wrap.addView(line); rowsBox.addView(wrap,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
            val row=InvoiceRow(name,qty,price,total); rows.add(row)
            val watcher=object: android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}; override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){ val v=(qty.text.toString().toDoubleOrNull()?:0.0)*(price.text.toString().toDoubleOrNull()?:0.0); total.text=money(v); updateTotal() }; override fun afterTextChanged(s:android.text.Editable?){} }
            qty.addTextChangedListener(watcher); price.addTextChangedListener(watcher)
        }
        addRow()
        action("＋ إضافة صنف آخر") { addRow() }
        val paid=field("المبلغ المدفوع الآن",true)
        val note=field("ملاحظات (اختياري)")
        body!!.addView(paid); body!!.addView(note); body!!.addView(totalView)
        action(if(purchase)"حفظ فاتورة المشتريات" else "اعتماد فاتورة البيع") {
            val partyName=party.text.toString().trim()
            if(partyName.isBlank()) { toast("أدخل الاسم أولاً"); return@action }
            val valid=rows.filter { it.name.text.isNotBlank() && (it.qty.text.toString().toDoubleOrNull()?:0.0)>0 }
            if(valid.isEmpty()) { toast("أضف صنفاً واحداً على الأقل بكمية صحيحة"); return@action }
            val total=totalValue(); val paidValue=(paid.text.toString().toDoubleOrNull()?:0.0).coerceIn(0.0,total)
            val type=if(purchase)"PURCHASE" else "SALE"
            val cv=android.content.ContentValues().apply { put("customer_id",-1); put("customer_name",partyName); put("date",now()); put("total",total); put("paid",paidValue); put("type",type); put("note",note.text.toString()) }
            val id=db.add("invoices",cv)
            valid.forEach { r ->
                val q=r.qty.text.toString().toDouble(); val p=r.price.text.toString().toDouble(); val name=r.name.text.toString().trim()
                val item=android.content.ContentValues().apply { put("invoice_id",id); put("product_name",name); put("qty",q); put("price",p); put("line_total",q*p) }; db.add("invoice_items",item)
                if(purchase) stockAdjust(name,q,p,true) else stockAdjust(name,-q,p,false)
            }
            db.audit("فاتورة $type","رقم $id - $partyName - الإجمالي ${money(total)} - المدفوع ${money(paidValue)}")
            toast("تم حفظ الفاتورة رقم $id. المتبقي ${money(total-paidValue)}")
            showPage("home")
        }
    }

    private fun stockAdjust(name:String, qty:Double, price:Double, buying:Boolean) {
        var found=-1L
        db.rows("SELECT id FROM products WHERE name=?", arrayOf(name)) { found=it.getLong(0) }
        if(found<0) { val v=android.content.ContentValues().apply { put("name",name); put("buy",if(buying)price else 0.0); put("sell",if(buying)0.0 else price); put("qty",qty); put("unit","قطعة") }; db.add("products",v) }
        else { val current=db.scalar("SELECT qty FROM products WHERE id=$found"); val v=android.content.ContentValues().apply { put("qty",current+qty); if(buying)put("buy",price) else put("sell",price) }; db.update("products",found,v) }
    }

    private fun customers() {
        addText(body!!,"الزبائن",20f,gold,true); action("＋ إضافة زبون") { customerDialog() }
        db.rows("SELECT id,name,phone FROM customers ORDER BY name") { c ->
            val id=c.getLong(0); val name=c.getString(1); val phone=c.getString(2)
            val debt=db.scalar("SELECT COALESCE(SUM(total-paid),0) FROM invoices WHERE type='SALE' AND customer_name='${name.replace("'","''")}'")
            val cardView=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,10,14,10); setBackgroundColor(card()) }
            addText(cardView,name,17f,fg(),true); addText(cardView,"$phone   •   المتبقي: ${money(debt)}",13f,gold)
            val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            val detail=Button(this).apply { text="كشف الحساب"; setOnClickListener { customerStatement(name) } }
            val sms=Button(this).apply { text="رسالة SMS"; setOnClickListener { sendDebtSms(name,phone,debt) } }
            actions.addView(detail,LinearLayout.LayoutParams(0,-2,1f)); actions.addView(sms,LinearLayout.LayoutParams(0,-2,1f)); cardView.addView(actions)
            body!!.addView(cardView,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
        }
    }
    private fun customerDialog() {
        val n=field("اسم الزبون"); val p=field("رقم الهاتف"); val note=field("ملاحظات")
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4); addView(n); addView(p); addView(note) }
        AlertDialog.Builder(this).setTitle("إضافة زبون").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
            if(n.text.isBlank()){toast("اكتب اسم الزبون");return@setPositiveButton}
            val v=android.content.ContentValues().apply { put("name",n.text.toString()); put("phone",p.text.toString()); put("note",note.text.toString()) }; db.add("customers",v); db.audit("إضافة زبون",n.text.toString()); showPage("customers")
        }.show()
    }
    private fun customerStatement(name:String) {
        val lines=StringBuilder("كشف حساب: $name\n\n")
        db.rows("SELECT id,date,total,paid FROM invoices WHERE type='SALE' AND customer_name=? ORDER BY id DESC",arrayOf(name)){ c -> lines.append("فاتورة #${c.getLong(0)} | ${c.getString(1)}\nالإجمالي ${money(c.getDouble(2))} | المدفوع ${money(c.getDouble(3))} | المتبقي ${money(c.getDouble(2)-c.getDouble(3))}\n")
            db.rows("SELECT product_name,qty,price,line_total FROM invoice_items WHERE invoice_id=${c.getLong(0)}"){ i-> lines.append("  ${i.getString(0)} × ${i.getDouble(1)} بسعر ${money(i.getDouble(2))} = ${money(i.getDouble(3))}\n") }
        }
        val debt=db.scalar("SELECT COALESCE(SUM(total-paid),0) FROM invoices WHERE type='SALE' AND customer_name='${name.replace("'","''")}'")
        lines.append("\nإجمالي الدين المتبقي: ${money(debt)}")
        AlertDialog.Builder(this).setTitle("كشف حساب الزبون").setMessage(lines.toString()).setPositiveButton("تصدير PDF"){_,_-> exportPdf("كشف-$name",lines.toString()) }.setNegativeButton("إغلاق",null).show()
    }
    private fun sendDebtSms(name:String,phone:String,debt:Double) {
        if(phone.isBlank()){toast("لا يوجد رقم هاتف مسجل");return}
        val msg="مرحباً $name، رصيدك المستحق في بسطتي هو ${money(debt)}. شكراً لك."
        try { startActivity(Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:${Uri.encode(phone)}")).putExtra("sms_body",msg)) } catch(_:Exception){toast("تعذر فتح تطبيق الرسائل")}
    }

    private fun products() {
        addText(body!!,"الأصناف والمخزون",20f,gold,true); action("＋ إضافة صنف") { productDialog() }
        db.rows("SELECT id,name,buy,sell,qty,unit FROM products ORDER BY name") { c ->
            val id=c.getLong(0); val name=c.getString(1); val buy=c.getDouble(2); val sell=c.getDouble(3); val qty=c.getDouble(4); val unit=c.getString(5)
            val v=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,10,14,10); setBackgroundColor(card()) }
            addText(v,name,17f,fg(),true); addText(v,"المتوفر: $qty $unit | شراء: ${money(buy)} | بيع: ${money(sell)}",12f,gold)
            val row=LinearLayout(this); val edit=Button(this).apply { text="تعديل"; setOnClickListener { productDialog(id,name,buy,sell,qty,unit) } }; val del=Button(this).apply { text="حذف"; setOnClickListener { confirmDelete("products",id,"الصنف $name") } }; row.addView(edit,LinearLayout.LayoutParams(0,-2,1f)); row.addView(del,LinearLayout.LayoutParams(0,-2,1f)); v.addView(row)
            body!!.addView(v,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
        }
    }
    private fun productDialog(id:Long=-1,name0:String="",buy0:Double=0.0,sell0:Double=0.0,qty0:Double=0.0,unit0:String="قطعة") {
        val n=field("اسم الصنف").apply { setText(name0) }; val buy=field("سعر الشراء",true).apply { setText(if(buy0==0.0)"" else buy0.toString()) }; val sell=field("سعر البيع",true).apply { setText(if(sell0==0.0)"" else sell0.toString()) }; val qty=field("الكمية المتوفرة",true).apply { setText(if(qty0==0.0)"" else qty0.toString()) }; val unit=field("الوحدة").apply { setText(unit0) }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4); listOf(n,buy,sell,qty,unit).forEach{addView(it)} }
        AlertDialog.Builder(this).setTitle(if(id<0)"إضافة صنف" else "تعديل صنف").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
            if(n.text.isBlank()){toast("أدخل اسم الصنف");return@setPositiveButton}; val v=android.content.ContentValues().apply { put("name",n.text.toString()); put("buy",buy.text.toString().toDoubleOrNull()?:0.0); put("sell",sell.text.toString().toDoubleOrNull()?:0.0); put("qty",qty.text.toString().toDoubleOrNull()?:0.0); put("unit",unit.text.toString()) }
            if(id<0)db.add("products",v) else db.update("products",id,v); db.audit("حفظ صنف",n.text.toString()); showPage("products")
        }.show()
    }

    private fun paymentDialog() {
        val name=field("اسم الزبون"); val amount=field("مبلغ الدفعة",true); val note=field("ملاحظات")
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4); addView(name); addView(amount); addView(note) }
        AlertDialog.Builder(this).setTitle("تسجيل دفعة قبض").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
            val n=name.text.toString().trim(); val a=amount.text.toString().toDoubleOrNull()?:0.0
            if(n.isBlank()||a<=0){toast("أدخل اسم الزبون ومبلغاً صحيحاً");return@setPositiveButton}
            val v=android.content.ContentValues().apply { put("customer_name",n); put("date",now()); put("amount",a); put("note",note.text.toString()) }; db.add("payments",v)
            var remaining=a
            db.rows("SELECT id,total,paid FROM invoices WHERE type='SALE' AND customer_name=? AND total>paid ORDER BY id",arrayOf(n)){ c-> if(remaining>0){ val due=c.getDouble(1)-c.getDouble(2); val pay=minOf(due,remaining); val cv=android.content.ContentValues().apply { put("paid",c.getDouble(2)+pay) }; db.update("invoices",c.getLong(0),cv); remaining-=pay } }
            db.audit("قبض دفعة","$n - ${money(a)}"); toast("تم تسجيل الدفعة"); showPage("home")
        }.show()
    }
    private fun expenseDialog() {
        val title=field("سبب المصروف"); val amount=field("المبلغ",true); val note=field("ملاحظات")
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4); addView(title); addView(amount); addView(note) }
        AlertDialog.Builder(this).setTitle("إضافة مصروف").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
            val a=amount.text.toString().toDoubleOrNull()?:0.0; if(title.text.isBlank()||a<=0){toast("أدخل البيانات بشكل صحيح");return@setPositiveButton}
            val v=android.content.ContentValues().apply { put("title",title.text.toString()); put("date",now()); put("amount",a); put("note",note.text.toString()) }; db.add("expenses",v); db.audit("مصروف",title.text.toString()+" "+money(a)); showPage("home")
        }.show()
    }

    private fun debts() {
        addText(body!!,"كشف ديون الزبائن",20f,gold,true)
        db.rows("SELECT customer_name, SUM(total-paid) AS due FROM invoices WHERE type='SALE' GROUP BY customer_name HAVING due>0.001 ORDER BY due DESC") { c ->
            val name=c.getString(0); val due=c.getDouble(1); val v=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,10,14,10); setBackgroundColor(card()) }; addText(v,name,17f,fg(),true); addText(v,"الدين المتبقي: ${money(due)}",15f,gold); val b=Button(this).apply { text="عرض كشف الحساب"; setOnClickListener { customerStatement(name) } }; v.addView(b); body!!.addView(v,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
        }
    }
    private fun suppliers() {
        addText(body!!,"الموردون",20f,gold,true); action("＋ إضافة مورد") {
            val n=field("اسم المورد"); val p=field("رقم الهاتف"); val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,4,20,4); addView(n); addView(p) }
            AlertDialog.Builder(this).setTitle("إضافة مورد").setView(box).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_-> if(n.text.isNotBlank()){val v=android.content.ContentValues().apply{put("name",n.text.toString());put("phone",p.text.toString())};db.add("suppliers",v);showPage("suppliers")} }.show()
        }
        db.rows("SELECT id,name,phone FROM suppliers ORDER BY name"){c->addText(body!!,"${c.getString(1)}  •  ${c.getString(2)}",16f,fg())}
    }
    private fun reports() {
        addText(body!!,"التقارير",20f,gold,true)
        action("تقرير المبيعات والديون PDF") {
            val s=StringBuilder("تقرير بسطتي\nتاريخ التقرير: ${now()}\n\n")
            db.rows("SELECT id,customer_name,date,total,paid FROM invoices WHERE type='SALE' ORDER BY id DESC"){c->s.append("فاتورة #${c.getLong(0)} - ${c.getString(1)} - ${c.getString(2)}\nالإجمالي ${money(c.getDouble(3))} | المدفوع ${money(c.getDouble(4))} | المتبقي ${money(c.getDouble(3)-c.getDouble(4))}\n")}
            s.append("\nإجمالي الديون: ${money(db.scalar("SELECT COALESCE(SUM(total-paid),0) FROM invoices WHERE type='SALE'"))}")
            exportPdf("تقرير-بسطتي",s.toString())
        }
        action("تقرير المشتريات PDF") { val s=StringBuilder("تقرير المشتريات\n\n"); db.rows("SELECT id,customer_name,date,total,paid FROM invoices WHERE type='PURCHASE'"){c->s.append("فاتورة #${c.getLong(0)} - ${c.getString(1)} - ${money(c.getDouble(3))}\n")}; exportPdf("تقرير-المشتريات",s.toString()) }
        action("تقرير المصروفات PDF") { val s=StringBuilder("تقرير المصروفات\n\n"); db.rows("SELECT title,date,amount FROM expenses ORDER BY id DESC"){c->s.append("${c.getString(1)} - ${c.getString(0)} - ${money(c.getDouble(2))}\n")}; exportPdf("تقرير-المصروفات",s.toString()) }
        action("كشف جميع الزبائن والديون PDF") { val s=StringBuilder("كشف ديون الزبائن\n\n"); db.rows("SELECT customer_name,SUM(total-paid) FROM invoices WHERE type='SALE' GROUP BY customer_name"){c->s.append("${c.getString(0)}: ${money(c.getDouble(1))}\n")}; exportPdf("كشف-الديون",s.toString()) }
    }
    private fun more() {
        addText(body!!,"إدارة بسطتي",20f,gold,true)
        action("المشتريات") { showPage("purchases") }; action("الموردون") { showPage("suppliers") }; action("الديون") { showPage("debts") }; action("التقارير و PDF") { showPage("reports") }; action("الإعدادات والنسخ الاحتياطي") { showPage("settings") }
    }
    private fun settings() {
        addText(body!!,"الإعدادات والحماية",20f,gold,true)
        addText(body!!,"صاحب البسطة: ${db.setting("owner")}",15f,fg())
        action("تغيير اسم صاحب البسطة") { val n=field("الاسم").apply{setText(db.setting("owner"))}; AlertDialog.Builder(this).setTitle("اسم صاحب البسطة").setView(n).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->db.setSetting("owner",n.text.toString());showPage("settings")}.show() }
        action("تفعيل/إلغاء الترحيب الصوتي") { val next=if(db.setting("welcome_voice","0")=="1")"0" else "1"; db.setSetting("welcome_voice",next); toast(if(next=="1")"تم تفعيل الترحيب الصوتي" else "تم إيقاف الترحيب الصوتي") }
        action("تصدير نسخة احتياطية") { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,"Bastati-backup.db"),createBackup) }
        action("استعادة نسخة احتياطية") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),restoreBackup) }
        action("تصدير تقرير PDF") { exportPdf("دليل-بسطتي","بسطتي - نظام إدارة البسطة\nصاحب التطبيق: Eng.Loay Alnawjaha\n\nيتيح التطبيق إدارة المبيعات والمشتريات والزبائن والديون والمخزون والمصروفات والتقارير.\nالبيانات تحفظ محلياً على الجهاز.") }
        addText(body!!,"حول التطبيق",16f,gold,true)
        addText(body!!,"بسطتي تطبيق لإدارة البسطات والمحلات الصغيرة، يجمع المبيعات والمشتريات والفواتير والديون والمخزون والمصروفات والتقارير في مكان واحد. يعمل دون اتصال بالإنترنت ويحفظ البيانات محلياً على الجهاز.\n\nتصميم وبرمجة Eng.Loay Alnawjaha",14f,fg())
        action("عرض سجل العمليات") { val s=StringBuilder("سجل العمليات\n\n"); db.rows("SELECT date,action,details FROM audit ORDER BY id DESC LIMIT 100"){c->s.append("${c.getString(0)} | ${c.getString(1)}\n${c.getString(2)}\n\n")}; AlertDialog.Builder(this).setTitle("سجل العمليات").setMessage(s.toString()).setPositiveButton("إغلاق",null).show() }
    }
    private fun confirmDelete(table:String,id:Long,label:String) { AlertDialog.Builder(this).setTitle("تأكيد الحذف").setMessage("هل تريد حذف $label؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف"){_,_->db.delete(table,id);db.audit("حذف",label);showPage(if(table=="products")"products" else "customers")}.show() }

    private fun exportPdf(fileName:String, text:String) {
        val doc=PdfDocument(); val pageInfo=PdfDocument.PageInfo.Builder(595,842,1).create(); val page=doc.startPage(pageInfo); val canvas=page.canvas
        val paint=Paint().apply { color=Color.BLACK; textSize=13f; typeface=Typeface.create("sans-serif",Typeface.NORMAL) }
        var y=48f
        text.split("\n").forEach { line ->
            if(y>800){ canvas.drawText("... تابع بقية التقرير من التطبيق",35f,y,paint); return@forEach }
            canvas.drawText(line.take(85),35f,y,paint); y+=20f
        }
        doc.finishPage(page)
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/pdf").putExtra(Intent.EXTRA_TITLE,"$fileName.pdf").putExtra("pdf_text",text),createPdf)
        pendingPdf=doc
    }
    private var pendingPdf:PdfDocument?=null
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(resultCode!=RESULT_OK||data?.data==null)return; val uri=data.data!!
        try {
            when(requestCode){
                createBackup -> { db.close(); contentResolver.openOutputStream(uri)?.use { out->FileInputStream(getDatabasePath("bastati.db")).use{it.copyTo(out)} }; db=Database(this); toast("تم تصدير النسخة الاحتياطية") }
                restoreBackup -> { db.close(); contentResolver.openInputStream(uri)?.use{input->FileOutputStream(getDatabasePath("bastati.db")).use{input.copyTo(it)}}; db=Database(this); toast("تمت استعادة النسخة. أعد فتح التطبيق إذا لم تظهر البيانات"); showPage("home") }
                createPdf -> { val doc=pendingPdf; if(doc!=null){contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)};doc.close();pendingPdf=null;toast("تم حفظ تقرير PDF")} }
            }
        } catch(e:Exception){ toast("تعذرت العملية: ${e.message}"); try{db=Database(this)}catch(_:Exception){} }
    }
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}
