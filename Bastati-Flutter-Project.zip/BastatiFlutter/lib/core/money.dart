/// All monetary values are stored as integer minor units (for ILS: agorot).
class MoneyMath {
  const MoneyMath._();
  static int lineTotal({required int unitPriceMinor, required int quantity}) {
    if (unitPriceMinor < 0 || quantity < 0) throw ArgumentError('القيمة والكمية لا يمكن أن تكونا سالبتين');
    return unitPriceMinor * quantity;
  }
  static int invoiceTotal({required Iterable<int> lineTotals, int discountMinor = 0}) {
    if (discountMinor < 0) throw ArgumentError('الخصم لا يمكن أن يكون سالباً');
    final subtotal = lineTotals.fold<int>(0, (sum, item) => sum + item);
    if (discountMinor > subtotal) throw ArgumentError('الخصم أكبر من إجمالي الفاتورة');
    return subtotal - discountMinor;
  }
  static String status({required int total, required int paid}) {
    if (paid < 0 || total < 0 || paid > total) throw ArgumentError('قيمة السداد غير صحيحة');
    if (paid == total) return 'PAID';
    if (paid == 0) return 'OPEN';
    return 'PARTIAL';
  }
  static int remaining({required int total, required int paid}) => total - paid;
}
