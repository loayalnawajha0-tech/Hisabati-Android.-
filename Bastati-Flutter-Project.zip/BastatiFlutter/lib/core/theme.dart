import 'package:flutter/material.dart';

class BastatiTheme {
  static const gold = Color(0xFFD6AE55);
  static ThemeData dark() => _theme(Brightness.dark);
  static ThemeData light() => _theme(Brightness.light);
  static ThemeData _theme(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(seedColor: gold, brightness: brightness, primary: gold, surface: dark ? const Color(0xFF17191E) : const Color(0xFFFFFEFA));
    return ThemeData(
      useMaterial3: true, brightness: brightness, colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF0D0F12) : const Color(0xFFF5F3EE),
      cardTheme: CardThemeData(color: dark ? const Color(0xFF191C21) : Colors.white, elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: dark ? Colors.white12 : Colors.black.withOpacity(.05)))),
      appBarTheme: AppBarTheme(backgroundColor: dark ? const Color(0xFF0D0F12) : const Color(0xFFF5F3EE), elevation: 0, centerTitle: false),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: dark ? const Color(0xFF202329) : Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17)),
      navigationBarTheme: NavigationBarThemeData(backgroundColor: dark ? const Color(0xFF17191E) : Colors.white, indicatorColor: gold.withOpacity(.18), labelTextStyle: WidgetStateProperty.all(const TextStyle(fontWeight: FontWeight.w700, fontSize: 11))),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: const Color(0xFF17130A), minimumSize: const Size(52, 52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), textStyle: const TextStyle(fontWeight: FontWeight.bold))),
    );
  }
}
