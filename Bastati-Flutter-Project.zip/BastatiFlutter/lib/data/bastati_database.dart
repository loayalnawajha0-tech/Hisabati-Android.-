import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class BastatiDatabase {
  BastatiDatabase._();
  static final BastatiDatabase instance = BastatiDatabase._();
  Database? _db;
  Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    _db = await openDatabase(p.join(root, 'bastati.db'), version: 1, onCreate: (db, version) async {
      await db.execute("CREATE TABLE settings (id INTEGER PRIMARY KEY CHECK(id=1), owner_name TEXT NOT NULL DEFAULT '', shop_name TEXT NOT NULL DEFAULT 'بسطتي', currency TEXT NOT NULL DEFAULT '₪', theme_mode TEXT NOT NULL DEFAULT 'dark', voice_enabled INTEGER NOT NULL DEFAULT 0)");
      await db.insert('settings', {'id':1});
      await db.execute('CREATE TABLE customers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, credit_limit INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, buy_price INTEGER NOT NULL DEFAULT 0, sell_price INTEGER NOT NULL DEFAULT 0, quantity INTEGER NOT NULL DEFAULT 0, min_quantity INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE invoices (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL, type TEXT NOT NULL, customer_id INTEGER, supplier_id INTEGER, subtotal INTEGER NOT NULL, discount INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL, paid INTEGER NOT NULL DEFAULT 0, due_date TEXT, notes TEXT, status TEXT NOT NULL, created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE invoice_items (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, product_id INTEGER, name TEXT NOT NULL, unit_price INTEGER NOT NULL, quantity INTEGER NOT NULL, line_total INTEGER NOT NULL)');
      await db.execute('CREATE TABLE payments (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, invoice_id INTEGER, amount INTEGER NOT NULL, note TEXT, created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT, created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE supplier_payments (id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id INTEGER, amount INTEGER NOT NULL, note TEXT, created_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, entity TEXT NOT NULL, entity_id INTEGER, details TEXT, created_at TEXT NOT NULL)');
      await db.execute('CREATE INDEX idx_invoice_date ON invoices(created_at)');
      await db.execute('CREATE INDEX idx_invoice_customer ON invoices(customer_id, status)');
      await db.execute('CREATE INDEX idx_product_name ON products(name)');
    });
    return _db!;
  }
  Future<Map<String,Object?>> settings() async { final r = await (await database).query('settings', where:'id=1'); return r.first; }
  Future<void> saveProfile(String owner, String shop, String currency) async { await (await database).update('settings', {'owner_name':owner,'shop_name':shop,'currency':currency}, where:'id=1'); }
  Future<void> setTheme(String mode) async { await (await database).update('settings', {'theme_mode':mode}, where:'id=1'); }
  Future<int> addCustomer(String name, String phone, int limit) async => (await database).insert('customers', {'name':name,'phone':phone,'credit_limit':limit,'created_at':DateTime.now().toIso8601String()});
  Future<List<Map<String,Object?>>> customers() async => (await database).query('customers', orderBy:'name COLLATE NOCASE');
  Future<int> addProduct(String name, int buy, int sell, int qty, int min) async => (await database).insert('products', {'name':name,'buy_price':buy,'sell_price':sell,'quantity':qty,'min_quantity':min,'created_at':DateTime.now().toIso8601String()});
  Future<List<Map<String,Object?>>> products() async => (await database).query('products', orderBy:'name COLLATE NOCASE');
  Future<Map<String,int>> dashboard() async {
    final db = await database; final now = DateTime.now(); final start = DateTime(now.year,now.month,now.day).toIso8601String();
    Future<int> sum(String table, String column, {String? where, List<Object?>? args}) async { final r = await db.rawQuery('SELECT COALESCE(SUM($column),0) AS v FROM $table ${where == null ? '' : 'WHERE $where'}', args); return (r.first['v'] as num).toInt(); }
    return {'sales':await sum('invoices','total',where:'type=? AND created_at>=?',args:['SALE',start]),'received':await sum('invoices','paid',where:'type=? AND created_at>=?',args:['SALE',start]),'expenses':await sum('expenses','amount',where:'created_at>=?',args:[start]),'debt':await sum('invoices','(total-paid)',where:'type=? AND status IN (?,?)',args:['SALE','OPEN','PARTIAL'])};
  }
}
