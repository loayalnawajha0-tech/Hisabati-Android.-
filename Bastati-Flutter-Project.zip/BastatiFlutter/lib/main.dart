import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/theme.dart';
import 'data/bastati_database.dart';

final themeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.dark);
final dashboardProvider = FutureProvider((ref) => BastatiDatabase.instance.dashboard());
final customersProvider = FutureProvider((ref) => BastatiDatabase.instance.customers());
final productsProvider = FutureProvider((ref) => BastatiDatabase.instance.products());

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(child: BastatiApp(initialDark: prefs.getBool('dark_mode') ?? true)));
}

class BastatiApp extends ConsumerWidget {
  const BastatiApp({super.key, required this.initialDark});
  final bool initialDark;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Restore the saved appearance once; the provider remains the live source of truth.
    final mode = ref.watch(themeProvider);
    if (mode == ThemeMode.dark && !initialDark) {
      WidgetsBinding.instance.addPostFrameCallback((_) => ref.read(themeProvider.notifier).state = ThemeMode.light);
    }
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بسطتي',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
      theme: BastatiTheme.light(), darkTheme: BastatiTheme.dark(), themeMode: mode,
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox()),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends ConsumerStatefulWidget {
  const HomeShell({super.key});
  @override ConsumerState<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends ConsumerState<HomeShell> {
  int index = 0;
  final pages = const [DashboardScreen(), InvoicesScreen(), CustomersScreen(), InventoryScreen(), SettingsScreen()];
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: IndexedStack(index: index, children: pages)),
    bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v)=>setState(()=>index=v), destinations: const [
      NavigationDestination(icon:Icon(Icons.space_dashboard_outlined),selectedIcon:Icon(Icons.space_dashboard),label:'الرئيسية'),
      NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'الفواتير'),
      NavigationDestination(icon:Icon(Icons.people_outline),selectedIcon:Icon(Icons.people),label:'الزبائن'),
      NavigationDestination(icon:Icon(Icons.inventory_2_outlined),selectedIcon:Icon(Icons.inventory_2),label:'المخزون'),
      NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'الإعدادات'),
    ]),
  );
}

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});
  @override Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(dashboardProvider); final currency = '₪';
    return RefreshIndicator(onRefresh:()=>ref.refresh(dashboardProvider.future), child: ListView(padding:const EdgeInsets.fromLTRB(18,18,18,28), children:[
      Row(children:[
        Container(width:52,height:52,decoration:BoxDecoration(color:BastatiTheme.gold.withOpacity(.16),borderRadius:BorderRadius.circular(17)),child:const Icon(Icons.storefront_rounded,color:BastatiTheme.gold,size:29)),
        const SizedBox(width:12), const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('بسطتي',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),Text('إدارة تجارتك بكل سهولة',style:TextStyle(color:Colors.grey,fontSize:13))])),
        IconButton.filledTonal(onPressed:() async { final next=ref.read(themeProvider)==ThemeMode.dark?ThemeMode.light:ThemeMode.dark; ref.read(themeProvider.notifier).state=next; final p=await SharedPreferences.getInstance(); await p.setBool('dark_mode',next==ThemeMode.dark); },icon:Icon(ref.watch(themeProvider)==ThemeMode.dark?Icons.light_mode_outlined:Icons.dark_mode_outlined)),
      ]),
      const SizedBox(height:22),
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFFE8C777),Color(0xFFC39438)]),borderRadius:BorderRadius.circular(25),boxShadow:[BoxShadow(color:BastatiTheme.gold.withOpacity(.15),blurRadius:20,offset:const Offset(0,8))]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('مبيعات اليوم',style:TextStyle(color:Color(0xFF3C2C0D),fontWeight:FontWeight.bold)),const SizedBox(height:7),data.when(data:(v)=>Text('${_money(v['sales']??0)} $currency',style:const TextStyle(fontSize:34,fontWeight:FontWeight.w900,color:Color(0xFF21190A))),loading:()=>const Text('…',style:TextStyle(fontSize:34)),error:(_,__)=>const Text('تعذر التحميل')),const SizedBox(height:8),const Row(children:[Icon(Icons.trending_up,color:Color(0xFF3C2C0D),size:18),SizedBox(width:5),Text('ملخص حركة اليوم',style:TextStyle(color:Color(0xFF3C2C0D)))])])),
      const SizedBox(height:18),
      data.when(data:(v)=>GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.45,children:[_MetricCard(title:'المقبوض اليوم',value:'${_money(v['received']??0)} $currency',icon:Icons.account_balance_wallet,color:Colors.green),_MetricCard(title:'الديون المستحقة',value:'${_money(v['debt']??0)} $currency',icon:Icons.credit_score,color:Colors.redAccent),_MetricCard(title:'المصاريف اليوم',value:'${_money(v['expenses']??0)} $currency',icon:Icons.payments_outlined,color:Colors.orange),const _MetricCard(title:'صافي الحركة',value:'—',icon:Icons.insights,color:BastatiTheme.gold)]),loading:()=>const Center(child:CircularProgressIndicator()),error:(e,_)=>Text('تعذر تحميل الملخص: $e')),
      const SizedBox(height:24), const Text('إجراءات سريعة',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:12),
      GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:2.25,children:[_QuickAction(icon:Icons.add_shopping_cart,title:'فاتورة جديدة',onTap:()=>_showInvoice(context,ref)),_QuickAction(icon:Icons.person_add_alt_1,title:'زبون جديد',onTap:()=>_showCustomer(context,ref)),_QuickAction(icon:Icons.inventory_2_outlined,title:'إضافة صنف',onTap:()=>_showProduct(context,ref)),_QuickAction(icon:Icons.receipt_long,title:'تسجيل مصروف',onTap:()=>_showExpense(context))]),
    ]));
  }
}

class _MetricCard extends StatelessWidget { const _MetricCard({required this.title,required this.value,required this.icon,required this.color}); final String title,value; final IconData icon; final Color color; @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Icon(icon,color:color,size:25),Text(title,style:const TextStyle(color:Colors.grey,fontSize:13,fontWeight:FontWeight.w600)),FittedBox(fit:BoxFit.scaleDown,alignment:Alignment.centerRight,child:Text(value,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900))) ]))); }
class _QuickAction extends StatelessWidget { const _QuickAction({required this.icon,required this.title,required this.onTap}); final IconData icon; final String title; final VoidCallback onTap; @override Widget build(BuildContext context)=>FilledButton.tonal(onPressed:onTap,style:FilledButton.styleFrom(backgroundColor:Theme.of(context).cardTheme.color,foregroundColor:Theme.of(context).colorScheme.onSurface,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,color:BastatiTheme.gold),const SizedBox(width:8),Flexible(child:Text(title,style:const TextStyle(fontWeight:FontWeight.bold),overflow:TextOverflow.ellipsis))])); }

class InvoicesScreen extends ConsumerWidget { const InvoicesScreen({super.key}); @override Widget build(BuildContext context,WidgetRef ref)=>_SimpleListScreen(title:'الفواتير',subtitle:'إدارة فواتير البيع والشراء',icon:Icons.receipt_long,empty:'لا توجد فواتير بعد',action:FilledButton.icon(onPressed:()=>_showInvoice(context,ref),icon:const Icon(Icons.add),label:const Text('إنشاء فاتورة'))); }
class CustomersScreen extends ConsumerWidget { const CustomersScreen({super.key}); @override Widget build(BuildContext context,WidgetRef ref){final data=ref.watch(customersProvider);return Scaffold(appBar:AppBar(title:const Text('الزبائن',style:TextStyle(fontWeight:FontWeight.w900)),actions:[IconButton(onPressed:()=>_showCustomer(context,ref),icon:const Icon(Icons.person_add_alt_1))]),body:data.when(data:(rows)=>rows.isEmpty?_EmptyState(icon:Icons.people_outline,title:'لا يوجد زبائن بعد',subtitle:'أضف أول زبون وابدأ بتنظيم حساباته'):ListView.separated(padding:const EdgeInsets.all(16),itemCount:rows.length,separatorBuilder:(_,__)=>const SizedBox(height:10),itemBuilder:(c,i)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:BastatiTheme.gold.withOpacity(.18),child:const Icon(Icons.person,color:BastatiTheme.gold)),title:Text('${rows[i]['name']}',style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${rows[i]['phone']??'لا يوجد رقم هاتف'}'),trailing:const Icon(Icons.chevron_left)))),loading:()=>const Center(child:CircularProgressIndicator()),error:(e,_)=>Center(child:Text('$e'))),floatingActionButton:FloatingActionButton.extended(onPressed:()=>_showCustomer(context,ref),icon:const Icon(Icons.add),label:const Text('زبون جديد')));}}
class InventoryScreen extends ConsumerWidget { const InventoryScreen({super.key}); @override Widget build(BuildContext context,WidgetRef ref){final data=ref.watch(productsProvider);return Scaffold(appBar:AppBar(title:const Text('المخزون',style:TextStyle(fontWeight:FontWeight.w900)),actions:[IconButton(onPressed:()=>_showProduct(context,ref),icon:const Icon(Icons.add))]),body:data.when(data:(rows)=>rows.isEmpty?_EmptyState(icon:Icons.inventory_2_outlined,title:'المخزون فارغ',subtitle:'أضف الأصناف والكميات وأسعار البيع والشراء'):ListView.separated(padding:const EdgeInsets.all(16),itemCount:rows.length,separatorBuilder:(_,__)=>const SizedBox(height:10),itemBuilder:(c,i)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.shopping_bag_outlined)),title:Text('${rows[i]['name']}',style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('الكمية: ${rows[i]['quantity']}  •  سعر البيع: ${_money(rows[i]['sell_price'] as int)} ₪'),trailing:Text('شراء ${_money(rows[i]['buy_price'] as int)}')))),loading:()=>const Center(child:CircularProgressIndicator()),error:(e,_)=>Center(child:Text('$e'))),floatingActionButton:FloatingActionButton.extended(onPressed:()=>_showProduct(context,ref),icon:const Icon(Icons.add),label:const Text('إضافة صنف')));}}
class SettingsScreen extends ConsumerWidget { const SettingsScreen({super.key}); @override Widget build(BuildContext context,WidgetRef ref)=>Scaffold(appBar:AppBar(title:const Text('الإعدادات',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:SwitchListTile(value:ref.watch(themeProvider)==ThemeMode.dark,title:const Text('الوضع الليلي',style:TextStyle(fontWeight:FontWeight.bold)),subtitle:const Text('التبديل بين المظهر الداكن والفاتح'),secondary:const Icon(Icons.contrast),onChanged:(v)async{ref.read(themeProvider.notifier).state=v?ThemeMode.dark:ThemeMode.light;final p=await SharedPreferences.getInstance();await p.setBool('dark_mode',v);})),const SizedBox(height:10),const Card(child:ListTile(leading:Icon(Icons.backup_outlined),title:Text('النسخ الاحتياطي'),subtitle:Text('قريباً: تصدير واستعادة قاعدة البيانات'))),const Card(child:ListTile(leading:Icon(Icons.fingerprint),title:Text('قفل التطبيق'),subtitle:Text('قريباً: PIN والبصمة'))),const Card(child:ListTile(leading:Icon(Icons.info_outline),title:Text('حول بسطتي'),subtitle:Text('نظام إدارة البسطة والمحل الصغير'),)),const Padding(padding:EdgeInsets.all(18),child:Center(child:Text('تصميم وبرمجة Eng.Loay Alnawjaha',style:TextStyle(color:BastatiTheme.gold,fontWeight:FontWeight.bold))))])); }

class _SimpleListScreen extends StatelessWidget { const _SimpleListScreen({required this.title,required this.subtitle,required this.icon,required this.empty,required this.action}); final String title,subtitle,empty; final IconData icon; final Widget action; @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(title,style:const TextStyle(fontWeight:FontWeight.w900))),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:58,color:BastatiTheme.gold),const SizedBox(height:16),Text(empty,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(subtitle,style:const TextStyle(color:Colors.grey)),const SizedBox(height:20),action])))); }
class _EmptyState extends StatelessWidget { const _EmptyState({required this.icon,required this.title,required this.subtitle}); final IconData icon; final String title,subtitle; @override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:64,color:BastatiTheme.gold),const SizedBox(height:18),Text(title,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(subtitle,textAlign:TextAlign.center,style:const TextStyle(color:Colors.grey))]))); }

Future<void> _showCustomer(BuildContext context,WidgetRef ref) async {final name=TextEditingController(),phone=TextEditingController(),limit=TextEditingController(text:'0');await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('إضافة زبون'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'اسم الزبون')),const SizedBox(height:10),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'رقم الجوال')),const SizedBox(height:10),TextField(controller:limit,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'سقف الدين'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()async{if(name.text.trim().isEmpty)return;await BastatiDatabase.instance.addCustomer(name.text.trim(),phone.text.trim(),int.tryParse(limit.text)??0);ref.invalidate(customersProvider);Navigator.pop(c);},child:const Text('حفظ'))]));}
Future<void> _showProduct(BuildContext context,WidgetRef ref) async {final name=TextEditingController(),buy=TextEditingController(text:'0'),sell=TextEditingController(text:'0'),qty=TextEditingController(text:'0'),min=TextEditingController(text:'0');await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('إضافة صنف'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'اسم الصنف')),for(final pair in [('سعر الشراء',buy),('سعر البيع',sell),('الكمية',qty),('حد التنبيه',min)])Padding(padding:const EdgeInsets.only(top:9),child:TextField(controller:pair.$2,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:pair.$1)))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()async{if(name.text.trim().isEmpty)return;await BastatiDatabase.instance.addProduct(name.text.trim(),int.tryParse(buy.text)??0,int.tryParse(sell.text)??0,int.tryParse(qty.text)??0,int.tryParse(min.text)??0);ref.invalidate(productsProvider);Navigator.pop(c);},child:const Text('حفظ'))]));}
Future<void> _showInvoice(BuildContext context,WidgetRef ref) async {ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('شاشة إنشاء الفواتير متعددة الأصناف ضمن مرحلة التطوير التالية.')));}
Future<void> _showExpense(BuildContext context) async {final amount=TextEditingController(),note=TextEditingController();await showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('تسجيل مصروف'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'المبلغ بالأغورة')),TextField(controller:note,decoration:const InputDecoration(labelText:'ملاحظة'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()async{final v=int.tryParse(amount.text);if(v==null||v<=0)return;final db=await BastatiDatabase.instance.database;await db.insert('expenses',{'category':'أخرى','amount':v,'note':note.text,'created_at':DateTime.now().toIso8601String()});Navigator.pop(c);},child:const Text('حفظ'))]));}
String _money(int value)=> (value/100).toStringAsFixed(2);
