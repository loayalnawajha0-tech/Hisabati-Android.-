# بسطتي | Bastati (Flutter)

تطبيق إدارة محل/بسطة يعمل محلياً دون إنترنت. هذه حزمة تأسيس Flutter قابلة للبناء عبر GitHub Actions.

## التقنية
- Flutter / Dart
- Riverpod لإدارة الحالة
- SQLite عبر sqflite
- SharedPreferences لحفظ تفضيل المظهر
- PDF/Printing وCharts وLocal Auth وTTS وShare/URL launch ضمن التبعيات المجهزة للتوسعة
- تخزين المبالغ كأعداد صحيحة بوحدة العملة الصغرى (مثلاً الأغورة للشيكل)

## المعمارية
- `lib/core`: الهوية البصرية وقواعد الحسابات المالية
- `lib/data`: قاعدة SQLite ومخطط الجداول
- `lib/features`: مجالات التطبيق (الرئيسية، الفواتير، الزبائن، المخزون، الإعدادات، التقارير)
- `test`: اختبارات قواعد حساب الفاتورة والسداد

## مخطط البيانات
`settings`, `customers`, `suppliers`, `products`, `invoices`, `invoice_items`, `payments`, `expenses`, `supplier_payments`, `audit_logs`.
توجد فهارس للتاريخ والزبون واسم الصنف لتسهيل البحث والاستعلامات.

## تشغيل محلي
1. ثبّت Flutter stable وAndroid Studio مع Android SDK.
2. من مجلد المشروع نفّذ:
   ```bash
   flutter create --platforms=android,ios --org com.loay.bastati .
   flutter pub get
   flutter test
   flutter run
   ```
3. لبناء APK:
   ```bash
   flutter build apk --release
   ```

## GitHub Actions
ارفع محتويات هذا المجلد إلى جذر المستودع، ثم افتح Actions وشغّل `Build Bastati Flutter APK`. الـ workflow يولّد مجلدات Android/iOS، يجلب التبعيات، يشغّل الاختبارات، ويبني APK ويرفعه كـ Artifact.

## حالة التنفيذ الحالية
هذه نسخة تأسيسية قابلة للتطوير: الثيم العربي RTL، لوحة مؤشرات، إضافة وعرض الزبائن والأصناف، قاعدة البيانات المحلية، تسجيل مصروف، تفضيل المظهر، وقواعد حساب مالية مختبرة. شاشات الفواتير الكاملة، توزيع الدفعات، تحديث المخزون عبر الفواتير، PDF عربي، النسخ الاحتياطي، القفل بالبصمة، التقارير والرسائل ما زالت تحتاج تنفيذ وربط واختبار قبل اعتبار التطبيق إصداراً إنتاجياً. لا تدّعِ أن هذه الميزات مكتملة حالياً.

## التوقيع
تصميم وبرمجة Eng.Loay Alnawjaha
