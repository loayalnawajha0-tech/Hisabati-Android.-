import 'package:flutter_test/flutter_test.dart';
import 'package:bastati/core/money.dart';

void main() {
  test('حساب مجموع السطر بدقة بوحدة العملة الصغرى', () {
    expect(MoneyMath.lineTotal(unitPriceMinor: 250, quantity: 3), 750);
  });
  test('حساب إجمالي الفاتورة بعد الخصم', () {
    expect(MoneyMath.invoiceTotal(lineTotals: [500, 750], discountMinor: 100), 1150);
  });
  test('السداد الجزئي يبقي الفاتورة جزئية والمتبقي محفوظاً', () {
    expect(MoneyMath.status(total: 20000, paid: 10000), 'PARTIAL');
    expect(MoneyMath.remaining(total: 20000, paid: 10000), 10000);
  });
  test('السداد الكامل يوسم الفاتورة مسددة', () {
    expect(MoneyMath.status(total: 20000, paid: 20000), 'PAID');
  });
}
